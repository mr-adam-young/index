<?php
# http://isme.interversal.systems/cypher-expand-jobs-isme.php
require_once __DIR__.'/includes/main-include.php';
require_once __DIR__.'/vendor/autoload.php';

# get info from .csv file with headers, convert to PHP array
$csv = interverse_csv_to_array('data/csv/test.csv');

# loop through the array, for each row do the following
foreach ($csv as $row) {
  # make a nice line :)
  echo "<hr>";

  # dump the row, except pretty
  echo "<pre>";
  print_r($row);
  echo "</pre>";

  # if this association is an organization, check for it. 
  # otherwise, it's a person. check to see if they exist
  if (!empty($row["Organization"])) {
    $cql = "MATCH (n:Organization { name:'".$row["Organization"]."' } ) RETURN n";
    if (interverse_neo4j($cql)) {
      # if results were returned, the organization exists, create a relationship to this project
      dry_interverse_neo4j("
        MATCH (m:Project), (n:Organization)
        WHERE m.ID = '".$row["ID"]."' AND n.name = '".$row["Organization"]."'
        CREATE (n)<-[r:CUSTOMER]-(m)");
    } else {
      # else they do not exist, create them and a relationship to the project
      dry_interverse_neo4j("
        MATCH (m:Project) 
        WHERE m.ID = '".$row["ID"]."'
        CREATE (n:Organization { name: '".$row["Organization"]."' } )<-[r:CUSTOMER]-(m)");
    }
  } else {
    $cql = "MATCH (n:Person { name: '".$row["CustomerName"]."' } ) RETURN n";
    if (interverse_neo4j($cql)) {
      # if results were returned, the person exists, create a relationship to this project
      dry_interverse_neo4j("
        MATCH (m:Project), (n:Person)
        WHERE m.ID = '".$row["ID"]."' AND n.name = '".$row["CustomerName"]."'
        CREATE (n)<-[r:CUSTOMER]-(m)");
    } else {
      # else they do not exist, create them and a relationship to the project
      dry_interverse_neo4j("
        MATCH (m:Project) 
        WHERE m.ID = '".$row["ID"]."'
        CREATE (n:Person { name: '".$row["CustomerName"]."' } )<-[r:CUSTOMER]-(m)");
    }
  }
  # check that the phone number isn't in the database already
  if (!empty($row['CustomerPhone'])) {
    $cql = "MERGE (n:PhoneNumber { number: '".$row["CustomerPhone"]."' } ) RETURN n";
    dry_interverse_neo4j($cql);
  }

  # flush the output buffer so the script doesn't appear to hang forever
  ob_flush();
}