<?php
# http://isme.interversal.systems/cypher-merge-jobs-isme.php
require_once __DIR__.'/includes/main-include.php';
require_once __DIR__.'/vendor/autoload.php';

# get info from .csv file with headers, convert to PHP array
$csv = interverse_csv_to_array('data/csv/inference.jobs.hess.csv');

# loop through the array, for each row do the following
foreach ($csv as $row) {
  # make a nice line :)
  echo "<hr><p>";
  print_r($row);
  echo "</p>";

  # if this association is an organization, check for it. 
  # otherwise, it's a person. check to see if they exist

  # was able to cut down on a lot of this with MERGE
  if (!empty($row["Organization"])) {
    $customer = "Organization";
  } elseif (!empty($row["Person"])) {
    $customer = "Person";
  } else {
    continue;
  }
  $cql = "MATCH (m:Project) WHERE m.ID = '".$row["ID"]."'
  MERGE (n:".$customer." { name:'".$row[$customer]."' } )
  WITH m, n
  MERGE (n)-[r:CUSTOMER]->(m)";
  interverse_neo4j($cql);
  # merge phone number
  if (!empty($row['Phone'])) {
    $cql = "MATCH (m:".$customer.") WHERE m.name = '".$row[$customer]."'
    MERGE (n:Telephone { number: '".$row["Phone"]."' } )
    WITH m, n
    MERGE (n)-[r:CONTACT]->(m)";
    interverse_neo4j($cql);
  }
  # merge email address
  if (!empty($row['Email'])) {
    $cql = "MATCH (m:".$customer.") WHERE m.name = '".$row[$customer]."'
    MERGE (n:Email { address: '".$row["Email"]."' } )
    WITH m, n
    MERGE (n)-[r:CONTACT]->(m)";
    interverse_neo4j($cql);
  }
  # merge physical address
  if (!empty($row['Street'])) {
    $cql = "MATCH (m:Project) WHERE m.ID = '".$row["ID"]."'
    MERGE (n:Address { street: '".$row["Street"]."', city: '".$row["City"]."', state: '".$row["State"]."', zip_code: '".$row["ZipCode"]."' } )
    WITH m, n
    MERGE (n)-[r:ASSOCIATION]-(m)";
    interverse_neo4j($cql);
  }
  # flush the output buffer so the script doesn't appear to hang forever
  ob_flush();
}