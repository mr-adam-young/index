<?php 
$title = "Timecard Test";

require 'includes/main-include.php';
require 'includes/panel-header.php';
?>
          
<?php require 'views/timecard.php'; ?>


<?php
require 'includes/panel-footer.php'; 
