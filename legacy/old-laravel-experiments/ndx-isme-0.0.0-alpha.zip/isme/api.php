<?php
require 'includes/main-include.php';

require 'includes/rest/get.php';
require 'includes/rest/post.php';
require 'includes/rest/put.php';
require 'includes/rest/delete.php';
?>

Test