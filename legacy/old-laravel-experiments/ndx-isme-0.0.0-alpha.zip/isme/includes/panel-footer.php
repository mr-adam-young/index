
</div>

<footer class="main-footer">
        <p><img src="images/logo-white-transparent-200px-lighter.png" alt=""/></p>
        <b>Version</b> <?php echo SITE_VERSION; ?>
    <!-- /.container -->
  </footer>
<!-- ./wrapper -->

</body>
</html>
