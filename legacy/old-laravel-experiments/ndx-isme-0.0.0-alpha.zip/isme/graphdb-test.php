<?php
# include everything
require_once __DIR__.'/includes/main-include.php';
require_once __DIR__.'/vendor/autoload.php';

# get info from mysql db
$rows = db('select * from Jobs');
$columns = db('select COLUMN_NAME, DATA_TYPE from INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = "Jobs"');

# create a map for Cypher to understand for Neo4j
foreach ($rows as $node) {
  $cql = "MATCH (m:Organization { name:'Hess Ornamental Iron' }) CREATE (n:Project {";
  foreach ($columns as $property) {
    if (!empty($node[$property['COLUMN_NAME']])) {
      $statement = $property['COLUMN_NAME'].':';
      # determine how to print to the map string depending on the type of the column in the mysql db
      switch ($property['DATA_TYPE']) {
        case ('varchar' || 'timestamp'):
          $statement .= '"'.addslashes($node[$property['COLUMN_NAME']]).'"';
          break;
        default:
          $statement .= $node[$property['COLUMN_NAME']];
      }
      $stack[] = $statement;
    }
  }
  $cql .= implode(',', $stack);
  $cql .= "})-[r:CREATOR]->(m) RETURN r";

  echo "<pre>";
  print_r($cql);
  echo "</pre>";

  # send the cypher query to the neo4j database
  echo "<pre>";
  try {
    $result = interverse_neo4j($cql);
    print_r($result);
  } 
  catch (Exception $exception) {
    var_dump($exception);
  }
  echo "</pre>";

  $stack = null;
  $cql = null;
}


/*

# https://www.w3schools.com/php/php_date.asp
# open a new file and write csv lines to it
$filename = 'data/csv/neo4j_test_'.date('Y-m-d_H-i-s').'.csv';
echo $filename;

# touch a file to create it
file_put_contents($filename, '');
$fp = fopen($filename, 'w');
foreach ($rows as $fields) { 
    fputcsv($fp, $fields);
}
fclose($fp);

*/