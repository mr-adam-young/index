<?php 
$title = "Information Management System";

require 'includes/main-include.php';
require 'includes/panel-header.php';
?>
          
<?php require 'views/employee.php'; ?>


<?php
require 'includes/panel-footer.php'; 
